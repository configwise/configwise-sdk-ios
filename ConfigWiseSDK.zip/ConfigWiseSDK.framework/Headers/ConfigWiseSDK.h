//
//  ConfigWiseSDK.h
//  ConfigWiseSDK
//
//  Created by Sergey Muravev on 19/11/2018.
//  Copyright © 2018 VipaHelda BV. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConfigWiseSDK.
FOUNDATION_EXPORT double ConfigWiseSDKVersionNumber;

//! Project version string for ConfigWiseSDK.
FOUNDATION_EXPORT const unsigned char ConfigWiseSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConfigWiseSDK/PublicHeader.h>


